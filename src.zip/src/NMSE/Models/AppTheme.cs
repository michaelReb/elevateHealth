﻿namespace NMSE.Models;

public enum AppTheme
{
    Default,
    Light,
    Dark
}
