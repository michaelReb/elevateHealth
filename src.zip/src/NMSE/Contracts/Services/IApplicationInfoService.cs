﻿namespace NMSE.Contracts.Services;

public interface IApplicationInfoService
{
    Version GetVersion();
}
