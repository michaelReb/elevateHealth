﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.IO;

namespace NMSE.ViewModels;

public class SimulationResultsViewModel : ObservableObject
{


 


    public SimulationResultsViewModel()
    {
    }



}
