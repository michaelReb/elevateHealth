﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace NMSE.ViewModels;

public class Data1ViewModel : ObservableObject
{
    public Data1ViewModel()
    {
    }
}
