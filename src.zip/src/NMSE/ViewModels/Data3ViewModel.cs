﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace NMSE.ViewModels;

public class Data3ViewModel : ObservableObject
{
    public Data3ViewModel()
    {
    }
}
