﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace NMSE.ViewModels;

public class ProjectDescriptionViewModel : ObservableObject
{
    public ProjectDescriptionViewModel()
    {
    }
}
