﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Diagnostics;
using System.Windows.Navigation;

namespace NMSE.ViewModels;

public class AboutViewModel : ObservableObject
{
    public AboutViewModel()
    {
    }


  }
