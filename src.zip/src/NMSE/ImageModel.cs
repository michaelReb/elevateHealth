﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NMSE;

public class ImageModel
  {
  public string? ImagePath { get; set; }

  }

